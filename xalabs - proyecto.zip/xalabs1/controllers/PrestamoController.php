<?php
require_once __DIR__ . '/../models/Prestamo.php';
require_once __DIR__ . '/../models/Socio.php';
require_once __DIR__ . '/../models/Libro.php';
require_once __DIR__ . '/../conexion.php';

function listarPrestamos() {
    global $pdo;
    $prestamos = Prestamo::listar($pdo);
    require __DIR__ . '/../views/prestamos/listar.php';
}

function formCrearPrestamo() {
    global $pdo;

    $Socios=Socio::listar($pdo);
    $Libros=Libro::listar($pdo);
    require __DIR__ . '/../views/prestamos/form.php';
}

function crearPrestamo() {
    global $pdo;

    $socioId = trim($_POST['socioId'] ?? '');
    $libroId = trim($_POST['libroId'] ?? '');
    $fechaPrestamo = trim($_POST['fechaPrestamo'] ?? '');

    if ($socioId === '' || $libroId === '' || $fechaPrestamo === '') {
        $error = 'Todos los campos son obligatorios.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    Prestamo::crear($pdo, $socioId, $libroId, $fechaPrestamo);

    header('Location: index.php?accion=listarPrestamos');
    exit;
}


function formEditarPrestamo() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    $prestamo = Prestamo::buscar($pdo, $id);

    if (!$prestamo) {
        header('Location: index.php?accion=listarPrestamos');
        exit;
    }

    $Socios = Socio::listar($pdo);
    $Libros = Libro::listar($pdo);
    require __DIR__ . '/../views/prestamos/form.php';
}

function editarPrestamo() {
    global $pdo;

    $id = (int)($_POST['id'] ?? 0);
    $socioId = trim($_POST['socioId'] ?? '');
    $libroId = trim($_POST['libroId'] ?? '');
    $fechaPrestamo = trim($_POST['fechaPrestamo'] ?? '');

    if ($id <= 0 || $socioId === '' || $libroId === '' || $fechaPrestamo === '') {
        $error = 'Todos los campos son obligatorios.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    Prestamo::editar($pdo, $id, $socioId, $libroId, $fechaPrestamo);

    header('Location: index.php?accion=listarPrestamos');
    exit;
}

function eliminarPrestamo() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        Prestamo::eliminar($pdo, $id);
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}

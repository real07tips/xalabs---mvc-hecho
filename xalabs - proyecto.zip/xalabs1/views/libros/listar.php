<?php require __DIR__ . '/../header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Libros</h1>
  <a href="index.php?accion=formCrear" class="btn btn-primary">+ Nuevo libro</a>
</div>

<?php if (empty($libros)): ?>
  <p class="text-muted">Todavía no hay libros cargados.</p>
<?php else: ?>
  <table class="table align-middle">
    <thead>
      <tr>
        <th>Portada</th>
        <th>Título</th>
        <th>Autor</th>
        <th class="text-end">Acciones</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($libros as $libro): ?>
      <tr>
        <td>
          <?php if ($libro->getImagen()): ?>
            <img src="img/portadas/<?= htmlspecialchars($libro->getImagen()) ?>"
                 width="60" height="80" class="rounded object-fit-cover"
                 alt="Portada de <?= htmlspecialchars($libro->getTitulo()) ?>">
          <?php else: ?>
            <span class="badge text-bg-secondary">Sin portada</span>
          <?php endif; ?>
        </td>
        <td><?= htmlspecialchars($libro->getTitulo()) ?></td>
        <td><?= htmlspecialchars($libro->getAutor()) ?></td>
        <td class="text-end">
          <a href="index.php?accion=formEditar&id=<?= (int)$libro->getId() ?>" class="btn btn-sm btn-outline-secondary">Editar</a>
          <a href="index.php?accion=eliminar&id=<?= (int)$libro->getId() ?>"
             class="btn btn-sm btn-outline-danger"
             onclick="return confirm('¿Eliminar este libro?');">Eliminar</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require __DIR__ . '/../footer.php'; ?>

<?php

require __DIR__ . '/controllers/LibroController.php';
require __DIR__ . '/controllers/SocioController.php';
require __DIR__ . '/controllers/PrestamoController.php';


$accion = $_GET['accion'] ?? 'listar';

switch ($accion) {
    // LIBROS
    case 'listar':
        listarLibros();
        break;
    case 'formCrear':
        formCrearLibro();
        break;
    case 'crear':
        crearLibro();
        break;
    case 'formEditar':
        formEditarLibro();
        break;
    case 'editar':
        editarLibro();
        break;
    case 'eliminar':
        eliminarLibro();
        break;

    // SOCIOS
    case 'listarSocios':
        listarSocios();
        break;
    case 'formCrearSocio':
        formCrearSocio();
        break;
    case 'crearSocio':
        crearSocio();
        break;
    case 'formEditarSocio':
        formEditarSocio();
        break;
    case 'editarSocio':
        editarSocio();
        break;
    case 'eliminarSocio':
        eliminarSocio();
        break;

        // PRESTAMOS

    case 'listarPrestamos':
        listarPrestamos();
        break;
    case 'formCrearPrestamo':
        formCrearPrestamo();
        break;
    case 'crearPrestamo':
        crearPrestamo();
        break;
    case 'formEditarPrestamo':
        formEditarPrestamo();
        break;
    case 'editarPrestamo':
        editarPrestamo();
        break;
    case 'eliminarPrestamo':
        eliminarPrestamo();
        break;

    default:
        http_response_code(404);
        echo 'Página no encontrada';
}

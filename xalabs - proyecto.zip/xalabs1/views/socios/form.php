<?php require __DIR__ . '/../header.php'; ?>

<h1 class="h3 mb-3"><?= isset($socio) ? 'Editar socio' : 'Nuevo socio' ?></h1>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST"
      action="index.php?accion=<?= isset($socio) ? 'editarSocio' : 'crearSocio' ?>"
      class="col-md-6">

  <?php if (isset($socio)): ?>
    <input type="hidden" name="id" value="<?= (int)$socio->getId() ?>">
  <?php endif; ?>

  <div class="mb-3">
    <label class="form-label">Nro. de socio</label>
    <input type="text" name="nro_socio" class="form-control"
           value="<?= isset($socio) ? htmlspecialchars($socio->getNroSocio()) : '' ?>" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Nombre</label>
    <input type="text" name="nombre" class="form-control"
           value="<?= isset($socio) ? htmlspecialchars($socio->getNombre()) : '' ?>" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Vínculo</label>
    <input type="text" name="vinculo" class="form-control"
           value="<?= isset($socio) ? htmlspecialchars($socio->getVinculo()) : '' ?>" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Estado</label>
    <select name="estado" class="form-select" required>
      <option value="habilitado" <?= isset($socio) && $socio->getEstado() === 'habilitado' ? 'selected' : '' ?>>Habilitado</option>
      <option value="suspendido" <?= isset($socio) && $socio->getEstado() === 'suspendido' ? 'selected' : '' ?>>Suspendido</option>
    </select>
  </div>

  <button type="submit" class="btn btn-primary"><?= isset($socio) ? 'Actualizar' : 'Guardar' ?></button>
  <a href="index.php?accion=listarSocios" class="btn btn-link">Cancelar</a>
</form>

<?php require __DIR__ . '/../footer.php'; ?>

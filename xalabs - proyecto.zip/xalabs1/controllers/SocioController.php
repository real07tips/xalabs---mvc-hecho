<?php
// controllers/SocioController.php

require_once __DIR__ . '/../models/Socio.php';
require_once __DIR__ . '/../conexion.php';

function listarSocios() {
    global $pdo;
    $socios = Socio::listar($pdo);
    require __DIR__ . '/../views/socios/listar.php';
}

function formCrearSocio() {
    require __DIR__ . '/../views/socios/form.php';
}

function crearSocio() {
    global $pdo;

    $nro_socio = trim($_POST['nro_socio'] ?? '');
    $nombre    = trim($_POST['nombre'] ?? '');
    $vinculo   = trim($_POST['vinculo'] ?? '');
    $estado    = trim($_POST['estado'] ?? '');

    if ($nro_socio === '' || $nombre === '' || $vinculo === '' || $estado === '') {
        $error = 'Todos los campos son obligatorios';
        require __DIR__ . '/../views/socios/form.php';
        return;
    }

    try {
        Socio::crear($pdo, $nro_socio, $nombre, $vinculo, $estado);
    } catch (PDOException $e) {
        $error = 'No se pudo crear el socio. Verificá que el número de socio no esté repetido.';
        require __DIR__ . '/../views/socios/form.php';
        return;
    }

    header('Location: index.php?accion=listarSocios');
    exit;
}

function formEditarSocio() {
    global $pdo;

    $socio = Socio::buscarPorId($pdo, $_GET['id'] ?? 0);

    if (!$socio) {
        header('Location: index.php?accion=listarSocios');
        exit;
    }

    require __DIR__ . '/../views/socios/form.php';
}

function editarSocio() {
    global $pdo;

    $id        = (int)($_POST['id'] ?? 0);
    $nro_socio = trim($_POST['nro_socio'] ?? '');
    $nombre    = trim($_POST['nombre'] ?? '');
    $vinculo   = trim($_POST['vinculo'] ?? '');
    $estado    = trim($_POST['estado'] ?? '');

    $socio = Socio::buscarPorId($pdo, $id);

    if (!$socio) {
        header('Location: index.php?accion=listarSocios');
        exit;
    }

    if ($nro_socio === '' || $nombre === '' || $vinculo === '' || $estado === '') {
        $error = 'Todos los campos son obligatorios';
        require __DIR__ . '/../views/socios/form.php';
        return;
    }

    try {
        Socio::actualizar($pdo, $id, $nro_socio, $nombre, $vinculo, $estado);
    } catch (PDOException $e) {
        $error = 'No se pudo actualizar el socio. Verificá que el número de socio no esté repetido.';
        require __DIR__ . '/../views/socios/form.php';
        return;
    }

    header('Location: index.php?accion=listarSocios');
    exit;
}

function eliminarSocio() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);

    try {
        Socio::eliminar($pdo, $id);
    } catch (PDOException $e) {
        $error = 'No se puede eliminar el socio porque tiene préstamos asociados.';
        $socios = Socio::listar($pdo);
        require __DIR__ . '/../views/socios/listar.php';
        return;
    }

    header('Location: index.php?accion=listarSocios');
    exit;
}

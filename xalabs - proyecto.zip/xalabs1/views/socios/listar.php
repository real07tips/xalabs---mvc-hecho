<?php require __DIR__ . '/../header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Socios</h1>
  <a href="index.php?accion=formCrearSocio" class="btn btn-primary">+ Nuevo socio</a>
</div>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if (empty($socios)): ?>
  <p class="text-muted">Todavía no hay socios cargados.</p>
<?php else: ?>
  <table class="table align-middle">
    <thead>
      <tr>
        <th>Nro. socio</th>
        <th>Nombre</th>
        <th>Vínculo</th>
        <th>Estado</th>
        <th class="text-end">Acciones</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($socios as $socio): ?>
      <tr>
        <td><?= htmlspecialchars($socio->getNroSocio()) ?></td>
        <td><?= htmlspecialchars($socio->getNombre()) ?></td>
        <td><?= htmlspecialchars($socio->getVinculo()) ?></td>
        <td>
          <?php if ($socio->getEstado() === 'habilitado'): ?>
            <span class="badge text-bg-success">Habilitado</span>
          <?php else: ?>
            <span class="badge text-bg-danger">Suspendido</span>
          <?php endif; ?>
        </td>
        <td class="text-end">
          <a href="index.php?accion=formEditarSocio&id=<?= (int)$socio->getId() ?>" class="btn btn-sm btn-outline-secondary">Editar</a>
          <a href="index.php?accion=eliminarSocio&id=<?= (int)$socio->getId() ?>"
             class="btn btn-sm btn-outline-danger"
             onclick="return confirm('¿Eliminar este socio?');">Eliminar</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require __DIR__ . '/../footer.php'; ?>

# Plan de solución y Scrum para la aplicación de biblioteca

## 1. Objetivo del documento
Este documento es una versión enfocada en la corrección real de los problemas detectados. Aquí se especifica qué hacer exactamente para solucionar cada brecha, qué prioridad tiene cada acción y cómo organizarlo en trabajo tipo Scrum.

## 2. Diagnóstico general
La aplicación tiene una base funcional para libros y socios, pero presenta varios problemas críticos:

- Falta de autenticación y control de permisos.
- Módulo de préstamos incompleto y con fallos de lógica.
- Inconsistencias entre nombres de columnas, variables y rutas.
- Ausencia de CSRF.
- Riesgos en carga de imágenes.
- Flujo del router incompleto.

## 3. Qué tengo que hacer exactamente para solucionar los problemas

### 3.1 Resolver la falta de autenticación
Se debe implementar login real con sesión.

Pasos concretos:
1. Crear una tabla de usuarios (o reutilizar una ya existente).
2. Crear una vista de login.
3. Crear un controlador `AuthController.php`.
4. Generar sesión con `session_start()` y guardar el usuario autenticado.
5. En cada acción crítica validar que exista una sesión activa.
6. Redirigir al login si no hay sesión.
7. Añadir control por roles: administrador, bibliotecario, etc.

Ejemplo de validación recomendada:
- Antes de cada acción sensible:
  - `if (!isset($_SESSION['usuario_id'])) { header('Location: index.php?accion=login'); exit; }`

### 3.2 Corregir el módulo de préstamos
Este es el problema más grave y requiere reescribirlo bien.

Pasos concretos:
1. Revisar la estructura real de la tabla `prestamos`.
2. Confirmar nombres reales de columnas: `id`, `socioId`, `libroId`, `fechaPrestamo` o `fecha`.
3. Corregir el constructor de la clase `Prestamo` para que el orden de parámetros sea consistente.
4. Corregir la consulta SQL para usar los alias correctos.
5. Ajustar el foreach en la vista para recorrer cada préstamo y usar `$p`.
6. Implementar `crearPrestamo()` con validación de:
   - socio no vacío
   - libro no vacío
   - fecha válida
   - que el libro exista
   - que el socio exista
   - que el libro no esté ya prestado o según la lógica de negocio
7. Implementar `editarPrestamo()` y `eliminarPrestamo()` en el controlador.
8. Agregar los casos faltantes en `index.php`:
   - `formEditarPrestamo`
   - `editarPrestamo`
   - `eliminarPrestamo`
9. Corregir los formularios para que usen acciones consistentes.

### 3.3 Corregir inconsistencias de nombres y variables
Hay desalineación entre:
- nombres de columnas SQL
- nombres del constructor
- variables en vista
- acciones del router

Paso concreto:
- Definir una convención única.
- Por ejemplo: usar siempre `socioId`, `libroId`, `fechaPrestamo`.
- Ajustar toda la app para esa convención.

### 3.4 Agregar protección CSRF
Es necesario para evitar falsificación de peticiones.

Pasos concretos:
1. Generar token CSRF al cargar cada formulario.
2. Guardarlo en sesión.
3. Incluirlo en el formulario como campo oculto.
4. Validarlo al procesar el POST.

Ejemplo:
- En el formulario: `<input type="hidden" name="csrf_token" value="...">`
- En el backend: `if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) { ... }`

### 3.5 Mejorar la seguridad de subidas de imágenes
Se debe proteger más la subida de portada.

Pasos concretos:
1. Guardar imágenes fuera del directorio público o en un directorio restringido.
2. Mantener validación MIME y tamaño.
3. Evitar nombres fáciles de adivinar.
4. No permitir ejecución del directorio.
5. Usar `basename()` y revisar rutas antes de borrar.

### 3.6 Corregir la navegación y UX
Es necesario normalizar rutas y mensajes.

Pasos concretos:
1. Revisar todos los enlaces.
2. Unificar la nomenclatura de acciones.
3. Corregir la vista de préstamos que está usando `prestamo` y `$p` inconsistentes.
4. Añadir mensajes claros: éxito, error, validación, permiso denegado.

## 4. Plan de corrección por prioridad

### Prioridad 1 - Seguridad crítica
1. Agregar sistema de login y sesión.
2. Proteger todas las acciones sensibles con autenticación.
3. Implementar CSRF.
4. Reforzar validación de subidas.

### Prioridad 2 - Bug crítico del negocio
1. Corregir `Prestamo.php`.
2. Implementar `crearPrestamo()`.
3. Completar `editarPrestamo()` y `eliminarPrestamo()`.
4. Arreglar la vista de préstamos.
5. Completar `index.php` con las acciones faltantes.

### Prioridad 3 - Calidad y mantenimiento
1. Estandarizar nombres de columnas y variables.
2. Mejorar mensajes de error.
3. Revisar validaciones de entrada.
4. Crear pruebas automatizadas.

## 5. Backlog tipo Scrum

### Product Backlog
- Como administrador, quiero iniciar sesión para acceder a la gestión del sistema.
- Como administrador, quiero crear, editar y eliminar libros sin errores.
- Como administrador, quiero crear, editar y eliminar socios sin errores.
- Como administrador, quiero crear, editar y eliminar préstamos sin errores.
- Como sistema, quiero impedir que usuarios no autenticados accedan a acciones sensibles.
- Como sistema, quiero proteger formularios con tokens CSRF.
- Como sistema, quiero validar uploads de imágenes para evitar archivos maliciosos.
- Como usuario, quiero ver mensajes claros al ejecutar acciones.
- Como equipo, queremos entregar la corrección en un plazo de 2 meses con entregables por sprint.

### Sprint 1 (Mes 1 - Semana 1 a 2): Seguridad base
- Historia 1: Login y sesión
- Historia 2: Control de permisos por acción
- Historia 3: Protección CSRF
- Historia 4: Revisión de uploads
- Entregable: sistema de autenticación funcional y rutas protegidas

### Sprint 2 (Mes 1 - Semana 3 a 4): Reparación de módulos funcionales
- Historia 5: Corregir modelo y controlador de préstamos
- Historia 6: Completar CRUD de préstamos
- Historia 7: Corregir vistas de préstamos y rutas
- Entregable: módulo de préstamos operativo y coherente

### Sprint 3 (Mes 2 - Semana 1 a 2): Calidad y validaciones
- Historia 8: Estandarizar nombres y validaciones
- Historia 9: Mejorar mensajes de error
- Historia 10: Preparar pruebas automatizadas
- Entregable: consistencia funcional y validaciones reforzadas

### Sprint 4 (Mes 2 - Semana 3 a 4): Optimización y cierre
- Historia 11: Revisión final de seguridad
- Historia 12: Pruebas de regresión
- Historia 13: Ajustes UX y documentación final
- Entregable: aplicación lista para producción inicial o staging

## 6. Definición de hecho (Definition of Done)
Una tarea se considera terminada cuando:
- la lógica funciona correctamente,
- la validación del lado del servidor está implementada,
- se verifica la sesión o permisos,
- no hay rutas rotas,
- el usuario recibe feedback claro,
- se realiza prueba manual o automatizada relevante,
- no se rompe el flujo de libros, socios ni préstamos.

## 7. Plan de testing recomendado
Después de corregir cada sprint, se debe hacer:

### Testing funcional
- Crear libro válido
- Crear libro con datos inválidos
- Editar libro
- Eliminar libro
- Crear socio válido
- Crear socio inválido
- Eliminar socio con préstamos asociados
- Crear préstamo válido
- Crear préstamo inválido
- Listar préstamos
- Editar préstamo
- Eliminar préstamo

### Testing de seguridad
- Intentar acceso sin login
- Intentar crear registro sin sesión
- Intentar borrar registro sin sesión
- Enviar formulario con token CSRF inválido
- Subir archivo `.php` o `.svg`
- Manipular `id` en la URL

## 8. Recomendación final
La prioridad no es solo arreglar errores visuales; lo principal es estabilizar la seguridad y el negocio. La app debe quedar con:
- login seguro,
- permisos,
- módulo de préstamos funcional,
- validaciones reales,
- vistas consistentes,
- y pruebas de regresión.

Sin eso, la aplicación no está lista para producción.

## 9. Cierre
Si se siguen estos pasos en orden, la app puede pasar de una versión inestable a una versión funcional y segura. La clave está en resolver primero seguridad, luego negocio y luego calidad.

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Biblioteca — Xa Labs</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark mb-4">
  <div class="container gap-2">
    <a class="navbar-brand" href="index.php?accion=listar">📚 XA Read - Biblioteca UTU</a>
    <a href="index.php?accion=listar" class="btn btn-light btn-sm">Libros</a>
    <a href="index.php?accion=listarSocios" class="btn btn-light btn-sm">Socios</a>
    <a href="index.php?accion=listarPrestamos" class="btn btn-light btn-sm">Préstamos</a>
  </div>
</nav>
<div class="container pb-5">

<?php
// controllers/LibroController.php

require_once __DIR__ . '/../models/Libro.php';
require_once __DIR__ . '/../conexion.php'; // expone $pdo

function listarLibros() {
    global $pdo;
    $libros = Libro::listar($pdo);
    require __DIR__ . '/../views/libros/listar.php';
}

function formCrearLibro() {
    require __DIR__ . '/../views/libros/form.php';
}

function crearLibro() {
    global $pdo;

    $titulo = trim($_POST['titulo'] ?? '');
    $autor  = trim($_POST['autor'] ?? '');

    if ($titulo === '' || $autor === '') {
        $error = 'Título y autor son obligatorios';
        require __DIR__ . '/../views/libros/form.php';
        return;
    }

    $imagen = guardarImagenSubida();

    if ($imagen === false) {
        $error = 'La portada debe ser JPG, JPEG, PNG, GIF o WEBP y no superar los 2 MB.';
        require __DIR__ . '/../views/libros/form.php';
        return;
    }

    $imagen = $imagen ?? 'default.png';

    Libro::crear($pdo, $titulo, $autor, $imagen);
    header('Location: index.php?accion=listar');
    exit;
}

function formEditarLibro() {
    global $pdo;

    $libro = Libro::buscarPorId($pdo, $_GET['id'] ?? 0);

    if (!$libro) {
        header('Location: index.php?accion=listar');
        exit;
    }

    require __DIR__ . '/../views/libros/form.php';
}

function editarLibro() {
    global $pdo;

    $id     = (int)($_POST['id'] ?? 0);
    $titulo = trim($_POST['titulo'] ?? '');
    $autor  = trim($_POST['autor'] ?? '');
    $libro  = Libro::buscarPorId($pdo, $id);

    if (!$libro) {
        header('Location: index.php?accion=listar');
        exit;
    }

    if ($titulo === '' || $autor === '') {
        $error = 'Título y autor son obligatorios';
        require __DIR__ . '/../views/libros/form.php';
        return;
    }

    // Si no se selecciona una portada nueva, se conserva la actual.
    $imagenNueva = guardarImagenSubida();

    if ($imagenNueva === false) {
        $error = 'La portada debe ser JPG, JPEG, PNG, GIF o WEBP y no superar los 2 MB.';
        require __DIR__ . '/../views/libros/form.php';
        return;
    }

    $imagen = $imagenNueva ?? $libro->getImagen();

    Libro::actualizar($pdo, $id, $titulo, $autor, $imagen);

    // Solo borramos la portada anterior después de guardar correctamente la nueva.
    if ($imagenNueva !== null && $libro->getImagen() && $libro->getImagen() !== 'default.png') {
        borrarImagen($libro->getImagen());
    }

    header('Location: index.php?accion=listar');
    exit;
}

function eliminarLibro() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    $libro = Libro::buscarPorId($pdo, $id);

    if ($libro) {
        Libro::eliminar($pdo, $id);

        if ($libro->getImagen() && $libro->getImagen() !== 'default.png') {
            borrarImagen($libro->getImagen());
        }
    }

    header('Location: index.php?accion=listar');
    exit;
}

/**
 * Guarda una portada en img/portadas y devuelve su nombre.
 * Devuelve null si no se subió archivo y false si la subida es inválida.
 */
function guardarImagenSubida() {
    if (!isset($_FILES['imagen']) || $_FILES['imagen']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($_FILES['imagen']['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    if ($_FILES['imagen']['size'] > 2 * 1024 * 1024) {
        return false;
    }

    $extension = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
    $permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!in_array($extension, $permitidas, true)) {
        return false;
    }

    // Validación real del contenido, no solo de la extensión.
    if (@getimagesize($_FILES['imagen']['tmp_name']) === false) {
        return false;
    }

    $nombre = uniqid('portada_', true) . '.' . $extension;
    $destino = __DIR__ . '/../img/portadas/' . $nombre;

    if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $destino)) {
        return false;
    }

    return $nombre;
}

function borrarImagen($nombre) {
    $nombre = basename($nombre);
    $ruta = __DIR__ . '/../img/portadas/' . $nombre;

    if (is_file($ruta)) {
        unlink($ruta);
    }
}

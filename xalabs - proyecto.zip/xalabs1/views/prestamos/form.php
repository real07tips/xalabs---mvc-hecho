<?php require __DIR__ . '/../header.php';
?>

<h1 class="h3 mb-3"><?= isset($prestamo) ? 'Editar prestamo' : 'Nuevo prestamo' ?></h1>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST"
      action="index.php?accion=<?= isset($prestamo) ? 'editarPrestamo' : 'crearPrestamo' ?>"
      class="col-md-6">

<?php if (isset($prestamo)): ?>
    <input type="hidden" name="id" value="<?= (int)$prestamo->getId() ?>">
<?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Libro *</label>
            <select name="libroId" class="form-select" required>
                <option value="">Seleccionar libro</option>
                <?php foreach ($Libros as $libro): ?>
                    <option value="<?=$libro->getId(); ?>" <?= isset($prestamo) && $prestamo->getLibroId() == $libro->getId() ? 'selected' : '' ?>><?= htmlspecialchars($libro->getTitulo()); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Socio *</label>
            <select name="socioId" class="form-select" required>
                <option value="">Seleccionar socio</option>
                <?php foreach ($Socios as $socio): ?>
                    <option value="<?= $socio->getId(); ?>" <?= isset($prestamo) && $prestamo->getSocioId() == $socio->getId() ? 'selected' : '' ?>><?= htmlspecialchars($socio->getNombre()); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha de Prestamo *</label>
            <input type="date" name="fechaPrestamo" class="form-control" value="<?= isset($prestamo) ? htmlspecialchars($prestamo->getFechaPrestamo()) : '' ?>" required>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary"><?= isset($prestamo) ? 'Guardar cambios' : 'Crear préstamo' ?></button>
            <a href="index.php?accion=listarPrestamos" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>
<?php require __DIR__ . '/../footer.php'; ?>
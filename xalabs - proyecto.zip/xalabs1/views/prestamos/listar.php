<?php require __DIR__ . '/../header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Prestamos</h1>
  <a href="index.php?accion=formCrearPrestamo" class="btn btn-primary">+ Nuevo Prestamo</a>
</div>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if (empty($prestamos)): ?>
  <p class="text-muted">Todavía no hay prestamos cargados.</p>
<?php else: ?>
  <table class="table align-middle">
    <thead>
      <tr>
        <th>Nombre de Socio</th>
        <th>Titulo de Libro</th>
        <th>Fecha de Prestamo</th>
        <th class="text-end">Acciones</th>
      </tr>
    </thead>
    <tbody>
   <?php foreach ($prestamos as $p): ?>
  <tr>
    <td><?= htmlspecialchars($p->getSocioNombre()) ?></td>
    <td><?= htmlspecialchars($p->getLibroTitulo()) ?></td>
    <td><?= htmlspecialchars($p->getFechaPrestamo()) ?></td>
   <td class="text-end">
          <a href="index.php?accion=formEditarPrestamo&id=<?= (int)$p->getId() ?>" class="btn btn-sm btn-outline-secondary">Editar Prestamo</a>
          <a href="index.php?accion=eliminarPrestamo&id=<?= (int)$p->getId() ?>"
             class="btn btn-sm btn-outline-danger"
             onclick="return confirm('¿Eliminar este prestamo?');">Eliminar</a>
        </td>
      </tr>
<?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require __DIR__ . '/../footer.php'; ?>

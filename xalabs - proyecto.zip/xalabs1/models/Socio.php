<?php
// models/Socio.php

class Socio {
    private $id;
    private $nro_socio;
    private $nombre;
    private $vinculo;
    private $estado;

    public function __construct($nro_socio, $nombre, $vinculo, $estado, $id = null) {
        $this->id = $id;
        $this->nro_socio = $nro_socio;
        $this->nombre = $nombre;
        $this->vinculo = $vinculo;
        $this->estado = $estado;
    }

    public function getId() { return $this->id; }
    public function getNroSocio() { return $this->nro_socio; }
    public function getNombre() { return $this->nombre; }
    public function getVinculo() { return $this->vinculo; }
    public function getEstado() { return $this->estado; }

    public static function listar($pdo) {
        $stmt = $pdo->prepare('SELECT * FROM socios ORDER BY nombre');
        $stmt->execute();

        $socios = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $f) {
            $socios[] = new Socio(
                $f['nro_socio'],
                $f['nombre'],
                $f['vinculo'],
                $f['estado'],
                $f['id']
            );
        }

        return $socios;
    }

    public static function buscarPorId($pdo, $id) {
        $stmt = $pdo->prepare('SELECT * FROM socios WHERE id = ?');
        $stmt->execute([(int)$id]);
        $f = $stmt->fetch(PDO::FETCH_ASSOC);

        return $f ? new Socio(
            $f['nro_socio'],
            $f['nombre'],
            $f['vinculo'],
            $f['estado'],
            $f['id']
        ) : null;
    }

    public static function crear($pdo, $nro_socio, $nombre, $vinculo, $estado) {
        $stmt = $pdo->prepare(
            'INSERT INTO socios (nro_socio, nombre, vinculo, estado) VALUES (?, ?, ?, ?)'
        );
        return $stmt->execute([$nro_socio, $nombre, $vinculo, $estado]);
    }

    public static function actualizar($pdo, $id, $nro_socio, $nombre, $vinculo, $estado) {
        $stmt = $pdo->prepare(
            'UPDATE socios SET nro_socio = ?, nombre = ?, vinculo = ?, estado = ? WHERE id = ?'
        );
        return $stmt->execute([$nro_socio, $nombre, $vinculo, $estado, (int)$id]);
    }

    public static function eliminar($pdo, $id) {
        $stmt = $pdo->prepare('DELETE FROM socios WHERE id = ?');
        return $stmt->execute([(int)$id]);
    }
}
